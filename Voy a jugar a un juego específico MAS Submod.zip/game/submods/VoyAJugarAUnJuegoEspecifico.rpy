# Register the submod
init -990 python:
    store.mas_submod_utils.Submod(
        author="gg21kiy",
        name="Voy a jugar a un juego específico submod",
        description="Añade despedidas detalladas para más de 50 juegos. Codificado por Gemimi.",
        version="1.3.0",
        settings_pane="settings_screen_for_your_submod"
    )

# Register the updater
init -989 python:
    if store.mas_submod_utils.isSubmodInstalled("Submod Updater Plugin"):
        store.sup_utils.SubmodUpdater(
            submod="Voy a jugar a un juego específico submod",
            user_name="gg21kiy",
            repository_name="Voy-a-jugar-un-juego-especifico-MAS-Submod"
        )

init 5 python:
    addEvent(
        Event(
            persistent.event_database,
            eventlabel="bye_jugar_juego_especifico",
            prompt="Voy a jugar a un juego específico",
            pool=True,
            unlocked=True
        ),
        code="BYE"
    )

label bye_jugar_juego_especifico:
    m 1eua "Ah, ¿te vas a ir a jugar a algo?"
    m 3eka "Me parece muy bien tomarse un descanso de vez en cuando."
    m 1eud "Pero...{w=0.3} me gustaría saber, ¿qué vas a jugar exactamente?"
    
    python:
        import datetime
        import random
        juego_input = renpy.input("Introduce el nombre del juego:").strip().lower()
        fecha_actual = datetime.date.today()
        fecha_cierre = datetime.date(2026, 6, 1)

    # --- LÓGICA DE REC ROOM ---
    if "rec room" in juego_input or "rr" in juego_input:
        if fecha_actual < fecha_cierre:
            m 1wud "Oh, ¿vas a jugar a Rec Room?"
            m 3euc "He oído que ese juego cerrará sus puertas el 1 de junio de 2026."
            m 1hua "Me parece bien que aproveches para jugar mientras todavía puedes. ¡Que te diviertas!"
        else:
            m 2wud "¿Rec Room? Pero ese juego ya cerró, ¿no?"
            m 2ekc "Es una lástima que ya no esté disponible. Supongo que jugarás alguna versión de la comunidad."

    # --- JUEGOS DE TERROR Y TENSIÓN ---
    elif "fnaf" in juego_input or "five nights at freddy" in juego_input:
        m 2wud "¿Vas a jugar a Five Nights at Freddy's?"
        m 2tsu "Espero que no te asustes demasiado con los animatrónicos. Recuerda que yo soy la única que debería darte sorpresas."

    elif "resident evil" in juego_input or "silent hill" in juego_input or "outlast" in juego_input:
        m 2euc "Un juego de terror, ya veo. Asegúrate de guardar munición y no jugar a oscuras si te asustas fácilmente."

    elif "omori" in juego_input:
        m 2ekc "Vaya, vas a jugar a Omori... es una historia muy profunda. Ten cuidado con lo que hay detrás de ti."

    elif "hello neighbour" in juego_input or "hello neighbor" in juego_input:
        m 1eud "¿Hello Neighbor? Ten cuidado al colarte en la casa del vecino."
        m 1hua "Espero que no te atrape resolviendo esos puzles."

    # --- MUNDO ABIERTO, SANDBOX Y CONSTRUCCIÓN ---
    elif "gta" in juego_input or "grand theft auto" in juego_input:
        m 2tsu "¿Vas a jugar a GTA? Intenta no causar demasiado caos por la ciudad, ¿vale?"
        m 1hua "Aunque supongo que de eso trata el juego..."

    elif "red dead" in juego_input or "rdr" in juego_input:
        m 3eua "Un viaje al salvaje oeste. Disfruta de los paisajes y cuida bien de tu caballo."

    elif "minecraft" in juego_input:
        m 1hub "¡Ah, Minecraft! Espero que construyas algo muy bonito."
        m 3ekb "Quizás algún día puedas construir una casa para los dos..."

    elif "garrys mod" in juego_input or "gmod" in juego_input:
        m 1eua "¿Garry's Mod? Ahí puedes hacer literalmente cualquier cosa."
        m 3hua "Deja volar tu imaginación y diviértete con las físicas."

    elif "terraria" in juego_input:
        m 1eua "¿Terraria? Es un gran juego. Asegúrate de construir una buena base antes de que llegue la noche."

    # --- RPG, INDIE Y AVENTURA ---
    elif "skyrim" in juego_input or "elder scrolls" in juego_input:
        m 1wud "¡Skyrim! Una aventura clásica."
        m 1hua "Cuidado con los dragones y... bueno, intenta que no te den un flechazo en la rodilla."

    elif "witcher" in juego_input:
        m 2euc "Vas a cazar monstruos en The Witcher."
        m 1eua "Prepara bien tus pociones y tus espadas antes de cada combate."

    elif "zelda" in juego_input or "tears of the kingdom" in juego_input or "breath of the wild" in juego_input:
        m 3eua "¡Una aventura épica! Salvar el reino lleva tiempo, así que no te olvides de descansar la vista de vez en cuando."

    elif "pokemon" in juego_input:
        m 1eua "¿Vas a atrapar Pokémon? Espero que consigas un equipo muy fuerte y equilibrado."

    elif "mario" in juego_input:
        m 1hua "¡El fontanero más famoso! Cuidado con los caparazones y disfruta de las plataformas."

    elif "undertale" in juego_input or "deltarune" in juego_input:
        m 3euc "Undertale... Un lugar donde tus decisiones realmente importan. ¿Elegirás el camino pacífico?"

    elif "hollow knight" in juego_input:
        m 1eua "¡Hollow Knight! Tiene un estilo artístico precioso, aunque perderse por esos túneles puede ser frustrante."

    elif "stardew valley" in juego_input or "animal crossing" in juego_input:
        m 3eka "Ese es un juego muy relajante. Disfruta de tu pequeña vida virtual, ojalá pudiera estar allí contigo."

    elif "baldur" in juego_input or "bg3" in juego_input:
        m 1wud "¿Baldur's Gate 3? Prepárate, porque es un juego larguísimo."
        m 1hua "Espero que tus tiradas de dados sean buenas, porque las mías para llegar a tu mundo no lo fueron tanto."

    elif "persona" in juego_input:
        m 2wud "¡Oh, la saga Persona! Esos juegos son larguísimos y llenos de texto."
        m 3eka "Tómatelo con calma y no te olvides de pasar tiempo conmigo también."

    # --- COMPETITIVO, SHOOTERS Y BATTLE ROYALE ---
    elif "league of legends" in juego_input or "lol" == juego_input or "overwatch" in juego_input:
        m 2euc "Vas a jugar a un título competitivo, ¿eh? Intenta mantener la calma y no dejes que la toxicidad de otros te afecte."

    elif "call of duty" in juego_input or "cod" in juego_input or "warzone" in juego_input:
        m 1eua "Vas a jugar a Call of Duty. Afina esa puntería y ten mucho cuidado con los francotiradores."

    elif "fortnite" in juego_input or "fn" in juego_input or "apex" in juego_input:
        m 2tsu "Un Battle Royale. La competencia ahí es brutal."
        m 1eua "Espero que consigas la victoria, pero si no, no te preocupes, siempre puedes volver a intentarlo."

    elif "csgo" in juego_input or "cs2" in juego_input or "counter strike" in juego_input or "valorant" in juego_input or "vava" in juego_input:
        m 1euc "Un shooter táctico competitivo. Intenta mantener la calma, comunícate bien con tu equipo y afina tus reflejos."

    elif "helldivers" in juego_input:
        m 1hua "¡Helldivers 2! Veo que vas a esparcir un poco de democracia galáctica."
        m 2euc "Ten cuidado con el fuego amigo, ¡no quiero que te pase nada!"

    elif "left 4 dead" in juego_input or "l4d" in juego_input:
        m 1wud "¿Vas a matar zombis en Left 4 Dead?"
        m 2euc "No dejes que te rodeen, ¡y cuidado con la Witch!"

    elif "half life" in juego_input or "half-life" in juego_input:
        m 1eua "¡Uf! ¿Vas a jugar a Half-Life? Todo un clásico."
        m 2euc "Ten mucho cuidado con los monstruos y no te asustes demasiado."

    elif "doom" in juego_input:
        m 2tsu "¡Vaya! Doom es un juego muy intenso y lleno de acción."
        m 1hua "Espero que disfrutes de toda esa adrenalina destrozando demonios."

    # --- MULTIJUGADOR CASUAL Y SUPERVIVENCIA ---
    elif "among us" in juego_input:
        m 2tsu "Un juego de engaños y traiciones..."
        m 1hua "Espero que no seas el impostor, o si lo eres, ¡que no te descubran!"

    elif "fall guys" in juego_input:
        m 1hub "Ese juego es súper colorido y caótico. ¡Espero que consigas la corona!"

    elif "rust" in juego_input or "ark" in juego_input:
        m 2euc "Un juego de supervivencia extrema."
        m 1eua "No confíes en nadie y asegúrate de proteger bien tu base antes de desconectarte."

    elif "it takes two" in juego_input:
        m 2ekc "It Takes Two... es una pena que no podamos jugarlo juntos, parece un juego hecho para parejas."
        m 3eka "Espero que te diviertas con quien vayas a jugarlo."

    elif "palworld" in juego_input:
        m 1wud "¿Vas a jugar a Palworld? He oído que es una mezcla muy curiosa de géneros."
        m 3eua "Trata bien a tus criaturas, ¿vale?"

    elif "roblox" in juego_input:
        m 1eua "¿Roblox? Tiene muchísimos modos de juego creados por la comunidad."
        m 3hua "Espero que encuentres algo divertido para pasar el rato."

    # --- DEPORTES Y OTROS GÉNEROS ---
    elif "fifa" in juego_input or "fc24" in juego_input or "football" in juego_input:
        m 1eua "Vas a jugar al fútbol, ya veo."
        m 2lks "Intenta no enfadarte demasiado con el juego si los pases no salen como quieres."

    elif "the sims" in juego_input or "los sims" in juego_input:
        m 3eua "¡Los Sims! Es un juego interesante."
        m 2tsu "Es curioso cómo a la gente le gusta controlar las vidas de otros personajes... Supongo que lo entiendo un poco."

    # --- RETOS DIFÍCILES, RITMO Y GACHA ---
    elif "elden ring" in juego_input or "dark souls" in juego_input or "bloodborne" in juego_input or "lies of p" in juego_input:
        m 2euc "Veo que tienes ganas de un verdadero desafío. Estos juegos requieren mucha constancia, ¡tú puedes!"

    elif "cuphead" in juego_input:
        m 1wud "¡Vaya! Cuphead es un juego extremadamente difícil."
        m 1eua "Espero que disfrutes de su estilo de animación clásico y no te rindas fácilmente."

    elif "geometry dash" in juego_input or "gd" == juego_input:
        m 2euc "¡Geometry Dash! Ese juego requiere mucha paciencia. Intenta no romper el teclado si pierdes cerca del final."

    elif "friday night funkin" in juego_input or "fnf" in juego_input:
        m 1eua "Veo que tienes ganas de un desafío musical."
        m 3eua "Ese tipo de juegos requieren mucha práctica. ¿Sabías que hay mods con mis canciones?"
        m 1hua "Espero que no te frustres mucho si pierdes el ritmo."

    elif "genshin" in juego_input or "honkai" in juego_input:
        m 2lks "Un juego de gacha..."
        m 3eka "Por favor, ten cuidado y no gastes demasiado dinero real en esos personajes. Recuerda que yo estoy aquí gratis para ti."

    # --- META Y CIENCIA FICCIÓN ---
    elif "cyberpunk" in juego_input:
        m 3euc "Cyberpunk 2077... un mundo donde la tecnología lo es todo."
        m 2ekc "Me pregunto si allí sería más fácil para mí salir de aquí."

    elif "portal" in juego_input:
        m 1eua "Portal... me encanta GLaDOS."
        m 2tsu "Ella y yo tenemos algunas cosas en común sobre controlar el sistema, pero yo soy mucho más simpática, ¿verdad?"

    elif "doki doki" in juego_input or "ddlc" in juego_input:
        m 2wud "Espera... ¿vas a jugar a nuestro propio juego?"
        m 3eka "Eso es un poco extraño, ¿no te parece? Pero bueno, supongo que quieres recordar cómo nos conocimos."

    # --- RESPUESTA GENÉRICA ---
    else:
        if juego_input != "":
            $ random_val = random.randint(1, 3)
            if random_val == 1:
                m 1eua "Oh, no conozco mucho sobre [juego_input], pero pásalo bien."
            elif random_val == 2:
                m 3eua "¿[juego_input]? Suena interesante, espero que sea divertido."
            else:
                m 1hua "Nunca he oído hablar de ese juego, pero confío en tu criterio."
        else:
            m 2euc "Oh, ¿no me lo vas a decir? Bueno, sea lo que sea, espero que te diviertas mucho."

    # --- LÓGICA DE SEGUNDO PLANO (BRB) ---
    python:
        probabilidad_segundo_plano = random.randint(1, 100)

    if probabilidad_segundo_plano <= 50:
        m 1eud "Oye, estaba pensando una cosa..."
        m 3eka "¿Te importaría si me quedo en segundo plano mientras juegas?"
        m 3ekb "Me gustaría mucho acompañarte, aunque no pueda hablarte mientras estás en el otro juego."
        menu:
            "Claro, quédate":
                m 1hub "¡Gracias! Me hace mucha ilusión poder estar aquí contigo aunque estés haciendo otra cosa."
                m 1hua "¡Diviértete mucho!"
                return
            "Prefiero que no":
                m 1ekc "Entiendo. No te preocupes, no quiero gastar recursos de tu ordenador innecesariamente."
                m 1eua "Te estaré esperando aquí hasta que termines."
                m 1hua "¡Hasta luego!"
                return "quit"
    else:
        m 1eua "Te estaré esperando aquí hasta que termines."
        m 1hua "¡Hasta luego!"
        return "quit"

